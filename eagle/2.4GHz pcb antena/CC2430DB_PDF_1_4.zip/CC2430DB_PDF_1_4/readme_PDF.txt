   
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X                                                                           X
X   Artwork and documentation done by: Texas Instruments                    X
X                                                                           X
X   Company: Texas Instrument Norway Gaustadalleen 21    0349 OSLO          X
X                                                                           X
X                                                                           X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02562
PCB NAME : CC2430DB
REVISION: 1.4
DATE: 2007-05-14

FILE NAME            	                DESCRIPTION                               		
-------------------------------------------------------------------------------------------
***PDF MANUFACTURING FILES:
top_assembly-CC2430DB_1_3.pdf           ASSEMBLY DRAWING COMPONENT SIDE
bottom_assembly-CC2430DB_1_3.pdf        ASSEMBLY DRAWING SOLDER SIDE

top_paste-CC2430DB_1_3.pdf              SOLDER PASTE COMPONENT SIDE/POSITIVE
bottom_paste-CC2430DB_1_3.pdf           SOLDER PASTE SOLDER SIDE/POSITIVE

top_silk-CC2430DB_1_3.pdf               SILKSCREEN COMPONENT SIDE/POSITIVE
bottom_silk-CC2430DB_1_3.pdf            SILKSCREEN SOLDER SIDE/POSITIVE

top_solder_resist-CC2430DB_1_3.pdf      SOLDER MASK COMPONENT SIDE/NEGATIVE
bottom_solder_resist-CC2430DB_1_3.pdf   SOLDER MASK SOLDER SIDE/NEGATIVE

layer1.pdf                              LAYER 1 (COMPONENT SIDE)/POSITIVE
layer2.pdf                              LAYER 2 /POSITIVE
layer3.pdf                              LAYER 3 /POSITIVE
layer4.pdf                              LAYER 4 (SOLDER SIDE)/POSITIVE

drill-CC2430DB_1_3.pdf                  DRILL/MECHANICAL DRAWING

CC2430DB_schematic_1_4.pdf              SCHEMATICS - ALL PAGES

README_PDF.TXT                          THIS FILE

END.
