   
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X                                                                           X
X   Artwork and documentation done by: Texas Instruments                    X
X                                                                           X
X   Company: Texas Instrument Norway Gaustadalleen 21    0349 OSLO          X
X                                                                           X
X                                                                           X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02562
PCB NAME : CC2430DB
REVISION: 1.3
DATE: 2007-03-27


FILE NAME            	DESCRIPTION                               		FILE TYPE
-------------------------------------------------------------------------------------------
***PCB ASSEMBLY FILES:
ASSYCOMP.SPL            ASSEMBLY DRAWING COMPONENT SIDE                         EXT. GERBER
ASSYSOLD.SPL            ASSEMBLY DRAWING SOLDER SIDE                            EXT. GERBER

PASTCOMP.SPL         	SOLDER PASTE COMPONENT SIDE/POSITIVE                    EXT. GERBER
PASTSOLD.SPL            SOLDER PASTE SOLDER SIDE/POSITIVE                       EXT. GERBER

P&P_COMP.REP            PICK AND PLACE COORDINATES, COMPONENT SIDE              ASCII

DRILL.SPL               DRILL/MECHANICAL DRAWING                                EXT. GERBER
	
EXT_GERBER.USR          PCB PHOTOPLOTTER DEFINITION FILE                        ASCII

README_PBA.TXT          THIS FILE                                               ASCII


END.
