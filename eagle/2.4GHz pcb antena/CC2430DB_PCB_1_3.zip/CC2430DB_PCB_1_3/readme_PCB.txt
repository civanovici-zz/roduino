XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X   Artwork and documentation done by: Texas Instruments AS                     X
X   Company: Texas Instruments AS                                               X
X   Address: Gaustadall�en 21    0349 OSLO                                      X
X                                                                               X
X                                                                               X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02562
PCB NAME : CC2430DB
REVISION: 1.3
DATE: 2005-12-05
MANUFACTURER : 
QUANTITY:   See order

Manufacturers marking: Two letter + year + week
The two letter code shall identify the manufaturer and is decided by the manufacturer. 
No logos or other identifyers are allowed.
The marking shall be in silk screen print at secondary side of the PCB, or in solder 
resist if no silk print at secondary side.

FILE: CC2430DB_PCB_RD.ZIP PACKED WITH WinZIP 

PCB DESCRIPTION:4 LAYER PCB 1.112 MM NOMINAL THICKNESS WITH 0.35um Cu PER LAYER
NOMINAL LAYER THICKNESS (NOT CRITICAL):
                LAYER 1-2: 0.321 MM DIELECTRIC FR4 
                LAYER  2-3: 0.34 MM DIELECTRIC FR4
                LAYER 3-4: 0.321 MM DIELECTRIC FR4
                Dielectric constant for FR4 is 4.5
                Dimensions in manufacturing files are in mils (0.001 inch)
                DOUBLE SIDE SOLDER MASK,
                DOUBLE SIDE SILKSCREEN,
                8 MIL MIN TRACE WIDTH AND 8 MIL MIN ISOLATION.

                 
FILE NAME            	DESCRIPTION                               		FILE TYPE
-------------------------------------------------------------------------------------------
***PCB MANUFACTURING FILES:
L1.SPL                  LAYER 1 COMPONENT SIDE/POSITIVE                         EXT. GERBER
L2.SPL                  LAYER 2 GROUND PLANE/POSITIVE                           EXT. GERBER
L3.SPL                  LAYER 3 VCC PLANE/POSITIVE                              EXT. GERBER
L4.SPL                  LAYER 2 SOLDER SIDE/POSITIVE                            EXT. GERBER

STOPCOMP.SPL         	SOLDER MASK COMPONENT SIDE/NEGATIVE                     EXT. GERBER
STOPSOLD.SPL         	SOLDER MASK SOLDER SIDE/NEGATIVE                        EXT. GERBER

SILKCOMP.SPL         	SILKSCREEN COMPONENT SIDE/POSITIVE            	        EXT. GERBER
SILKSOLD.SPL            SILKSCREEN SOLDER SIDE/POSITIVE		                EXT. GERBER

PASTCOMP.SPL         	SOLDER PASTE COMPONENT SIDE/POSITIVE                    EXT. GERBER
PASTSOLD.SPL            SOLDER PASTE SOLDER SIDE/POSITIVE                       EXT. GERBER

NCDRILL.SPL             NC DRILL THROUGH HOLE                                   EXCELLON
NCDRILL.REP             NC DRILL REPORT                                         ASCII
DRILL.SPL               DRILL/MECHANICAL DRAWING                                EXT. GERBER
DRILL.REP               DRILL REPORT                                            ASCII
	
EXT_GERBER.USR          PCB PHOTOPLOTTER DEFINITION FILE                        ASCII
CNC.USR                 NC DRILL DEVICE FILE                                    ASCII
	
README_PCB.TXT          THIS FILE                                               ASCII


END.
